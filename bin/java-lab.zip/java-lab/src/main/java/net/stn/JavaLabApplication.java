package net.stn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaLabApplication.class, args);
	}
}
